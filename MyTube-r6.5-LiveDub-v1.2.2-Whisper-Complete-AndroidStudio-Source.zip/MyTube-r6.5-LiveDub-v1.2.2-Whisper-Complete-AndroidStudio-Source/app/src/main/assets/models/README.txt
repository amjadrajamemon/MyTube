The one-click compile_apk.bat downloads the official multilingual whisper.cpp ggml-tiny.bin
(~75 MiB) into this folder before Gradle runs, so the generated APK contains its ASR model and
works offline after installation. Runtime also supports verified first-run provisioning if an APK
was built manually without the asset.
Expected SHA-1: bd577a113a864445d4c299885e0cb97d4ba92b5f
