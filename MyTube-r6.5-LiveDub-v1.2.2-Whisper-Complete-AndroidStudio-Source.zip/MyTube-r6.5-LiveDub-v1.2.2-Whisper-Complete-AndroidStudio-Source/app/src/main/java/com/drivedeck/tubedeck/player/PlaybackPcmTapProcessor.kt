package com.drivedeck.tubedeck.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer

/** Pass-through Media3 processor that mirrors decoded PCM16 to LiveDub without touching playback. */
class PlaybackPcmTapProcessor(
    private val consumer: (ByteArray, Int, Int) -> Unit
) : BaseAudioProcessor() {
    private var sampleRate = 0
    private var channels = 0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size <= 0) return
        val copy = ByteArray(size)
        val duplicate = inputBuffer.duplicate()
        duplicate.get(copy)
        consumer(copy, sampleRate, channels)

        val output = replaceOutputBuffer(size)
        output.put(inputBuffer)
        output.flip()
    }
}
