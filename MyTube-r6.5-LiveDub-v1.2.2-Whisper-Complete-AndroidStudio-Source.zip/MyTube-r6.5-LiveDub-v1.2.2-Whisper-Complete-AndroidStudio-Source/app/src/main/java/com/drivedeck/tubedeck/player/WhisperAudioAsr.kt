package com.drivedeck.tubedeck.player

import android.content.Context
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import dev.ffmpegkit.whisper.WhisperModel
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Zero-cloud audio ASR bridge. Decoded player PCM is segmented by a lightweight energy VAD,
 * written as short WAV clips, and transcribed locally by whisper.cpp.
 */
class WhisperAudioAsr(
    context: Context,
    private val onText: (String, String?) -> Unit,
    private val onStatus: (String) -> Unit
) {
    companion object {
        const val MODEL_NAME = "ggml-tiny.bin"
        const val MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin"
        // Published whisper.cpp model checksum (SHA-1).
        const val MODEL_SHA1 = "bd577a113a864445d4c299885e0cb97d4ba92b5f"
    }

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val modelDir = File(appContext.filesDir, "whisper-models").apply { mkdirs() }
    private val modelFile = File(modelDir, MODEL_NAME)
    private var model: WhisperModel? = null
    private val transcribing = AtomicBoolean(false)
    private val lock = Any()
    private var pcm = ArrayList<Short>(16000 * 8)
    private var speechFrames = 0
    private var silentFrames = 0
    private var sourceLanguage: String? = null
    private var enabled = false

    fun setEnabled(value: Boolean, languageHint: String?) {
        enabled = value
        sourceLanguage = languageHint?.substringBefore('-')?.takeUnless { it == "auto" }
        if (!value) synchronized(lock) { resetLocked() }
        else ensureModel()
    }

    fun modelInstalled(): Boolean = modelFile.isFile && modelFile.length() > 70_000_000L

    fun ensureModel() {
        if (!enabled) return
        if (model != null) return
        scope.launch {
            try {
                if (!modelInstalled()) {
                    if (!installBundledModel()) {
                        onStatus("Installing multilingual Whisper Tiny model (~75 MB)…")
                        downloadModel()
                    }
                }
                if (!verifySha1(modelFile)) throw IllegalStateException("Whisper model checksum mismatch")
                onStatus("Loading offline Whisper model…")
                model = Whisper.loadModel(appContext, modelFile.absolutePath)
                onStatus("Audio Live Dub ready • Whisper Tiny offline")
            } catch (t: Throwable) {
                onStatus("Whisper unavailable: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    /** Receives decoded PCM16 from Media3. It never blocks the playback thread. */
    fun accept(bytes: ByteArray, sampleRate: Int, channels: Int) {
        if (!enabled || model == null || sampleRate <= 0 || channels <= 0) return
        val copy = bytes.copyOf()
        scope.launch { processPcm(copy, sampleRate, channels) }
    }

    private fun processPcm(bytes: ByteArray, sampleRate: Int, channels: Int) {
        val shorts = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val mono = ShortArray(shorts.remaining() / channels)
        var i = 0
        while (shorts.remaining() >= channels) {
            var sum = 0
            repeat(channels) { sum += shorts.get().toInt() }
            mono[i++] = (sum / channels).toShort()
        }
        if (i == 0) return
        val used = if (i == mono.size) mono else mono.copyOf(i)
        val rms = sqrt(used.fold(0.0) { a, v -> a + v.toDouble() * v } / used.size) / 32768.0
        val speech = rms > 0.012

        var clip: ShortArray? = null
        synchronized(lock) {
            if (speech) { speechFrames++; silentFrames = 0 } else if (speechFrames > 0) silentFrames++
            if (speechFrames > 0) used.forEach { pcm.add(it) }
            val seconds = pcm.size.toDouble() / sampleRate
            if ((silentFrames >= 5 && seconds >= 0.8) || seconds >= 7.0) {
                clip = pcm.toShortArray()
                resetLocked()
            }
        }
        clip?.let { submitClip(it, sampleRate) }
    }

    private fun submitClip(samples: ShortArray, sampleRate: Int) {
        val whisperModel = model ?: return
        if (!transcribing.compareAndSet(false, true)) return
        scope.launch {
            val wav = File(appContext.cacheDir, "livedub-${System.nanoTime()}.wav")
            try {
                writeWav(wav, samples, sampleRate)
                val config = sourceLanguage?.let { WhisperConfig(language = it) } ?: WhisperConfig()
                val result = Whisper.transcribe(whisperModel, wav.absolutePath, config)
                val text = result.text.trim()
                val detected = sourceLanguage ?: runCatching {
                    result.javaClass.methods.firstOrNull { it.name == "getLanguage" && it.parameterCount == 0 }
                        ?.invoke(result)?.toString()?.substringBefore('-')
                }.getOrNull()
                if (text.isNotBlank()) onText(text, detected)
            } catch (t: Throwable) {
                onStatus("Whisper transcription error: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                wav.delete()
                transcribing.set(false)
            }
        }
    }


    private suspend fun installBundledModel(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            appContext.assets.open("models/$MODEL_NAME").use { input ->
                FileOutputStream(modelFile).use { output -> input.copyTo(output, 1024 * 256) }
            }
            if (!verifySha1(modelFile)) {
                modelFile.delete()
                false
            } else true
        }.getOrDefault(false)
    }

    private suspend fun downloadModel() = withContext(Dispatchers.IO) {
        val tmp = File(modelDir, "$MODEL_NAME.part")
        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000; readTimeout = 60_000; instanceFollowRedirects = true
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) error("model download HTTP ${connection.responseCode}")
            connection.inputStream.use { input ->
                FileOutputStream(tmp).use { output -> input.copyTo(output, 1024 * 256) }
            }
            if (!verifySha1(tmp)) error("downloaded model failed checksum")
            if (modelFile.exists()) modelFile.delete()
            if (!tmp.renameTo(modelFile)) error("could not install model")
        } finally { connection.disconnect(); if (tmp.exists()) tmp.delete() }
    }

    private fun verifySha1(file: File): Boolean {
        if (!file.isFile) return false
        val md = MessageDigest.getInstance("SHA-1")
        file.inputStream().use { input ->
            val b = ByteArray(1024 * 256)
            while (true) { val n = input.read(b); if (n <= 0) break; md.update(b, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }.equals(MODEL_SHA1, true)
    }

    private fun writeWav(file: File, samples: ShortArray, sampleRate: Int) {
        val dataSize = samples.size * 2
        FileOutputStream(file).use { out ->
            fun ascii(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
            fun le16(v: Int) = out.write(byteArrayOf((v and 255).toByte(), ((v ushr 8) and 255).toByte()))
            fun le32(v: Int) = out.write(byteArrayOf((v and 255).toByte(), ((v ushr 8) and 255).toByte(), ((v ushr 16) and 255).toByte(), ((v ushr 24) and 255).toByte()))
            ascii("RIFF"); le32(36 + dataSize); ascii("WAVEfmt "); le32(16); le16(1); le16(1)
            le32(sampleRate); le32(sampleRate * 2); le16(2); le16(16); ascii("data"); le32(dataSize)
            val bb = ByteBuffer.allocate(dataSize).order(ByteOrder.LITTLE_ENDIAN)
            samples.forEach { bb.putShort(it) }; out.write(bb.array())
        }
    }

    private fun resetLocked() { pcm.clear(); speechFrames = 0; silentFrames = 0 }

    fun close() {
        enabled = false
        model?.let { Whisper.releaseModel(it) }
        model = null
        scope.cancel()
    }
}
