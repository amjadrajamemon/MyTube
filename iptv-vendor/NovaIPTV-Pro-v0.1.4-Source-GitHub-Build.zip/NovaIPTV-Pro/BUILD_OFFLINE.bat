@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ====================================================
echo  Nova IPTV Pro - Offline APK Builder (Windows)
echo ====================================================
set "NOVA_GRADLE=%LOCALAPPDATA%\NovaIPTV\gradle-8.11.1\gradle-8.11.1\bin\gradle.bat"
if not exist "%NOVA_GRADLE%" (echo Offline build requires a successful online setup first.& pause & exit /b 1)
call "%NOVA_GRADLE%" --offline --no-daemon testDebugUnitTest assembleDebug
if errorlevel 1 (echo BUILD FAILED: all Android SDK and Gradle dependencies must already be cached.& pause & exit /b 1)
echo SUCCESS: app\build\outputs\apk\debug\app-debug.apk
pause
