@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ====================================================
echo  Nova IPTV Pro - Online APK Builder (Windows)
echo ====================================================
where java >nul 2>&1 || (echo Java 17+ is required. Install JDK 17 or 21.& pause & exit /b 1)
where powershell >nul 2>&1 || (echo Windows PowerShell is required.& pause & exit /b 1)
set "NOVA_CACHE=%LOCALAPPDATA%\NovaIPTV\gradle-8.11.1"
if not exist "%NOVA_CACHE%\gradle-8.11.1\bin\gradle.bat" (
 echo Downloading Gradle 8.11.1 official distribution...
 powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-gradle.ps1" -Destination "%NOVA_CACHE%"
 if errorlevel 1 (echo Gradle download or verification failed.& pause & exit /b 1)
)
call "%NOVA_CACHE%\gradle-8.11.1\bin\gradle.bat" --no-daemon testDebugUnitTest assembleDebug
if errorlevel 1 (echo BUILD FAILED. Check JDK, Android SDK 36, network access, and Gradle output.& pause & exit /b 1)
echo.
echo SUCCESS: app\build\outputs\apk\debug\app-debug.apk
pause
