#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon testDebugUnitTest assembleDebug
else
  echo 'Install Gradle 8.11.1 and Android SDK 36, or use GitHub Actions.' >&2
  exit 1
fi
