# ◈ Nova IPTV Pro — Android IPTV Player

**Version:** 0.1.0 | **Status:** Working original-code foundation; automated APK compilation and real-device compatibility not yet certified.

Native Android IPTV client for touch devices, tablets, Android TV and TV boxes. No subscriptions, pirate channels or provider accounts are bundled. Use legally authorized sources.

## What works in this source release

- Import remote **M3U/M3U8**, or a local M3U file using Android's file picker.
- Connect to an **Xtream-compatible** service; browse **Live TV**, **VOD**, **Series** and their episodes, subject to provider availability.
- Import remote **XMLTV** (including .gz); browse next-48-hour programme listings and display "now playing" metadata.
- Playback via **AndroidX Media3/ExoPlayer**: HTTP(S) progressive media, HLS, DASH, SmoothStreaming, and RTSP, subject to device codecs/network compatibility.
- Custom main player view, **Fit / Zoom / Stretch**, **PiP** where supported, player track controls, previous/next live channel, basic retry, external player chooser.
- Live/Movies/Series/Favorites/Recent/All views; search, group browsing, history, local source removal.
- **16 resolution-independent preset HD palettes**, custom background/accent/text colors, 5 text sizes and 3 row-density settings.
- Keyboard, touch, Android TV D-pad and common channel/media key support.
- Remote artwork thumbnails with bounded downloads and 8 MB memory cache.
- AES-256-GCM **Android Keystore encrypted local library**, including playlist stream URLs and Xtream credentials; no plaintext secrets in the repo.
- GitHub Actions unit-test / debug-APK workflow; optional online and cache-only Windows build scripts.

## What is NOT implemented or certified yet

Do not confuse compatibility proposals with shipped features. This version **does not** include built-in LibVLC, SRT/UDP/RTMP engine, SMB/FTP browsing, recording, timeshift, multiview, Chromecast, licensed DRM integration, remote account sync, parental control, EPG artwork, background audio service, premium image-based theme packs, offline downloads, provider health monitoring or provider-specific token refresh. Media3 playback does not guarantee compatibility with every codec/provider. The UI is a streamlined adaptive list view, not yet a complete cinematic TV dashboard. These are tracked in `docs/ROADMAP.md`.

## Build via GitHub Actions — easiest without a PC

1. Create a new **empty** public or private GitHub repository named `NovaIPTV-Pro`.
2. **Extract this ZIP**, then upload the **contents of `NovaIPTV-Pro/`** to the repository root (not the ZIP file as one attachment). Include the hidden `.github/workflows/android-apk.yml` file and the `app/` folder.
3. Commit to `main`. Open the repository's **Actions** tab → **Build Nova IPTV Android APK** → **Run workflow** (or use the automatic push build).
4. Open the finished workflow run → **Artifacts** → `NovaIPTV-Pro-universal-debug`. Download the artifact ZIP and extract `app-debug.apk`.
5. Sideload the APK onto the phone, Android TV, TV box or tablet; allow installs from trusted local files when prompted.

**Important:** Only a green GitHub Actions run establishes that the project compiled successfully. GitHub may require enabling Actions for new repositories. APKs are not included in this source ZIP, and it is not an app installation ZIP.

## Build from Windows

- Requires JDK 17+ (JDK 17 or 21 recommended), Android SDK Platform 36 and Build Tools 36.0.0, internet on first build. Set `ANDROID_HOME`/`ANDROID_SDK_ROOT` or put `local.properties` in the project with `sdk.dir=...`.
- Double-click `BUILD_ONLINE.bat` to download and **verify SHA-256 of the official Gradle distribution**, then resolve Android dependencies and compile.
- `BUILD_OFFLINE.bat` is **cache-only**, not magic offline dependency provisioning. It works only after every dependency is cached and an Android SDK is installed.
- Linux/macOS: `BUILD_ONLINE.sh` requires Gradle 8.11.1 already on PATH and Android SDK 36.
- Output: `app/build/outputs/apk/debug/app-debug.apk` (universal APK). Android dependencies will download from Google Maven/Maven Central on first build.

## Quick start

Launch the app → `+ Source` → provide a M3U URL, choose a local file, or log in to your authorized Xtream-compatible portal. Channel rows are selectable by remote OK/Enter or touch; long-press a row for Favorites and Guide. Switch tabs across Live, Movies, Series, Favorites, Recent, All. Use `Themes` and `⚙` to customize.

## Minimum requirements and limitations

Android 7.0/API 24 or newer; PiP requires Android 8.0+ and OS support. Supported decoders, frame rates, HDR, HD/4K/8K resolution, subtitle formats, audio passthrough, DRM and streaming protocols depend on the device and licensed provider. Some custom portals do not implement standard Xtream endpoints. Portals with HTTP plaintext should be considered insecure; use HTTPS when available.

## Structure

```text
.github/workflows/android-apk.yml          CI tests + universal debug APK
app/src/main/java/.../ui/                Main screen, player, 16 theme palettes
app/src/main/java/.../core/              M3U, Xtream, EPG, networking, encrypted storage, artwork
app/src/main/java/.../model/             Catalog models
app/src/test/                            Parser and EPG tests
docs/ROADMAP.md                          Ranked competitive expansion roadmap
docs/AUDIT.md                            Scope, risks, test evidence
scripts/audit.py                         Reproducible repository static audit
BUILD_ONLINE.bat / BUILD_OFFLINE.bat      Windows build entrypoints
```

## Technology and provenance

Original Java/Android UI and domain code with **AndroidX Media3 1.11.1**, **Android Gradle Plugin 8.10.1**, **Gradle 8.11.1**, **Java 17** and **compileSdk 36**. Media3 is Apache-2.0 licensed. Refer to its upstream notices and third-party dependency licenses when distributing builds. Our own code is MIT licensed; see LICENSE.

Do not paste real portal login details, M3U token URLs, or EPG credentials into issues, CI logs, public repositories or screenshots.
