# Media3 and AndroidX supply their own consumer rules.
-dontwarn org.checkerframework.**
