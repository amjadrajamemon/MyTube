# Competitive Development Roadmap

Our design references the **functional strengths** of TiviMate, Sparkle TV, Televizo, OTT Navigator, Kodi and VLC, without copying their proprietary assets/code.

## Phase 1 — reliability and real-device certification (highest priority)

- [ ] Build in GitHub Actions; fix any AGP/dependency/manifest errors; install on actual phone, Android TV and low-memory box.
- [ ] Verify remote D-pad focus on all widgets and list item click vs long-click, all common air-mouse models, keyboards, and media next/prev keys.
- [ ] M3U regression corpus from lawful test streams: quoted attributes, BOM/CRLF, relative streams, tokenized URLs, gzip, duplicates, timeouts.
- [ ] Xtream provider adapters: authentication, category fallback, stream extension auto-fallback, series/episode metadata, portal-specific variants.
- [ ] Implement on-device watchdog for buffering/stall with bounded retry and non-looping stream-engine fallback.
- [ ] Verify switching channels never leaves two players audible.
- [ ] Lifecycle tests for PiP/Home/Back, audio focus, orientation, stopped activity and remote navigation.
- [ ] Accessibility contrast and focus audit; Android TV banner and launcher checks.

## Phase 2 — outperform TV UX leaders

- [ ] Cinema-style TV home: EPG preview, vertical mini player, columns, featured cards, high-resolution cached posters.
- [ ] Full interactive EPG guide: virtualized grid, day jump, current live marker, manual tvg-id mapping, provider timezone corrections.
- [ ] User-editable remote-key mappings, numeric channel entry, jump-back, hidden channels, configurable lists, sorting and smart categories.
- [ ] Profiles/parental controls, optional PIN and kid-safe libraries.
- [ ] Dedicated phone mode with compact gesture panel, orientation-specific layouts, tablet two-pane navigation.
- [ ] Theme designer: HD artwork packs, per-control size/color/transparency, animated effects with reduce-motion toggle.
- [ ] MediaSession + optional foreground audio-only service; consistent background playback and system controls.

## Phase 3 — playback compatibility

- [ ] Optional LibVLC native renderer behind isolated playback-engine interface, arm64/armeabi-v7a ABI testing.
- [ ] SRT, UDP multicast/RTP, RTMP and additional container/codec support on capable hardware or via external engine.
- [ ] Optional local file/SMB/DLNA/FTP browsing with permission-scoped access.
- [ ] Authorized Widevine/ClearKey integration, compatible license management (no DRM bypass).
- [ ] Chromecast / Google Cast where eligible; Bluetooth/audio focus and subtitle language controls.
- [ ] Picture-in-Picture improvements and multi-view where sufficient device resources exist.

## Phase 4 — recording and pro features

- [ ] Timeshift buffer and DVR with quota policy, SAF folder selection, scheduled recording and clear rights safeguards.
- [ ] Multi-recording conflict checker, EPG-driven scheduling, low-storage warnings.
- [ ] Per-provider health diagnostics, HTTP status, startup latency, buffer events, optional privacy-preserving telemetry.
- [ ] Data migration/export, backup, secure secrets handling, offline metadata.

## Success gates

Each feature must pass a compile job, unit coverage where feasible, and device smoke tests (touch phone, tablet, genuine Android TV/remote, old TV box). Report codecs, provider type, latency, memory use and failure logs without exposing stream credentials. Never mark a feature **implemented** until its code path is exercised on a test device.
