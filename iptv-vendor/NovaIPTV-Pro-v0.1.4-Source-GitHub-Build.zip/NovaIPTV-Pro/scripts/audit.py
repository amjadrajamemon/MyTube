#!/usr/bin/env python3
"""Local, dependency-free structural/static checks for Nova IPTV source package."""
import re, sys, os, hashlib
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
expected=[
 'settings.gradle','build.gradle','app/build.gradle','app/src/main/AndroidManifest.xml',
 '.github/workflows/android-apk.yml','README.md','LICENSE','docs/AUDIT.md',
 'app/src/main/java/com/novastream/iptv/ui/MainActivity.java',
 'app/src/main/java/com/novastream/iptv/ui/PlayerActivity.java',
 'app/src/main/java/com/novastream/iptv/core/M3uParser.java',
 'app/src/main/java/com/novastream/iptv/core/Xtream.java',
 'app/src/main/java/com/novastream/iptv/core/Epg.java',
 'app/src/main/java/com/novastream/iptv/core/SecureStore.java',
 'app/src/main/res/mipmap-nodpi/tv_banner.png',
 'app/src/test/java/com/novastream/iptv/core/M3uParserTest.java',
 'app/src/test/java/com/novastream/iptv/core/EpgTest.java',
]
fail=[]
for filename in expected:
 if not (root/filename).is_file():fail.append('MISSING '+filename)
for file in root.rglob('*.xml'):
 try:ET.parse(file)
 except Exception as e:fail.append(f'INVALID XML {file.relative_to(root)} {e}')
for file in root.rglob('*'):
 if not file.is_file() or file.suffix.lower() not in {'.java','.gradle','.md','.xml','.properties','.yml','.ps1','.bat'}:continue
 s=file.read_text(encoding='utf-8')
 if '\0' in s:fail.append(f'NUL byte {file.relative_to(root)}')
 if 'BEGIN PRIVATE KEY' in s:fail.append(f'Embedded key {file.relative_to(root)}')
 if re.search(r'(?i)(?:password|secret|api[_-]?key)\s*[=:]\s*[\"\'](?:[^\"\'+]{12,})[\"\']',s):
  # Source may contain test literals; review flagged items manually.
  if not file.name.endswith('Test.java'):fail.append(f'Potential hardcoded secret {file.relative_to(root)}')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
if 'android.permission.INTERNET' not in manifest:fail.append('Internet permission missing')
workflow=(root/'.github/workflows/android-apk.yml').read_text()
if 'assembleDebug' not in workflow or 'upload-artifact' not in workflow:fail.append('Missing APK build/upload steps')
for file in root.rglob('*'):
 if file.is_file() and file.stat().st_size>2*1024*1024:fail.append('File > 2 MB: '+str(file.relative_to(root)))
print(f'Validated {len(expected)} essential files, XML syntax, APK workflow and basic secret patterns.')
if fail:
 for f in fail: print('FAIL:',f)
 sys.exit(1)
print('PASS: static source package audit (not Android compilation or device certification)')
