param([Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$zip=Join-Path $Destination 'gradle-8.11.1-bin.zip'
$uri='https://services.gradle.org/distributions/gradle-8.11.1-bin.zip'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri $uri -OutFile $zip -UseBasicParsing
$hash=(Get-FileHash -Path $zip -Algorithm SHA256).Hash.ToLowerInvariant()
$checksumUrl='https://services.gradle.org/distributions/gradle-8.11.1-bin.zip.sha256'
$expected=((Invoke-WebRequest -Uri $checksumUrl -UseBasicParsing).Content.Trim().Split(' ')[0]).ToLowerInvariant()
if ($expected -notmatch '^[a-f0-9]{64}$' -or $hash -ne $expected) { throw 'Gradle SHA-256 verification failed' }
Write-Host "Verified Gradle distribution SHA-256: $hash"
Expand-Archive -LiteralPath $zip -DestinationPath $Destination -Force
if (-not (Test-Path (Join-Path $Destination 'gradle-8.11.1\bin\gradle.bat'))) { throw 'Gradle distribution structure invalid' }
